input_a = input("""
    안녕하세요
문자열의 함수를 알아봅시다.
""")
#print(input_a)
print(input_a.strip())
