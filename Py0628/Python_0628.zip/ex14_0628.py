print("TrainA10".isalnum())
print("10".isdigit())
