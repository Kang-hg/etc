list_b = [0, 1, 2, 3, 4, 5, 6]
print()

del list_b[3:6]
print(list_b)
print()

list_c = [0, 1, 2, 3, 4, 5, 6]
del list_c[:3]                  # [:3] = 3번 앞 까지, [3:] = 3번 부터
print(list_c)
print()
