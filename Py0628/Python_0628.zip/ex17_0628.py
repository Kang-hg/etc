a = "10 20 30 40 50".split(" ")
print(a)