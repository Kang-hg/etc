numbers = [273, 103, 5, 32, 65, 9, 72, 800, 99]

print()

for number in numbers:
    if number >= 100:
        print("- 100 이상의 수:", number)

print()
