str_input = input("숫자 입력> ")
num_input = float(str_input)

print()
print(num_input, "inch")
print((num_input * 2.54), "cm")
