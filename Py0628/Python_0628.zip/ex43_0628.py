for character in "안녕하세요":
    print("-", character)