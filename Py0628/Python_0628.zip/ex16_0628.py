print("안녕" in "안녕하세요")
print("잘자" in "안녕하세요")