print(10 == 100)
print(10 != 100)
print(10 < 100)
print(10 > 100)
print(10 <= 100)
print(10 >= 100)

print()
print("가방" == "가방")
print("가방" != "하마")
print("가방" < "하마")      # ㄱ ㄴ ㄷ  순
print("가방" > "하마")

x = 25
print()
print(10 < x < 50)
print(45 < x < 50)