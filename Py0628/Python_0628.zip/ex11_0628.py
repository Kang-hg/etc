output_a = 52.0
output_b = "{:g}".format(output_a)      # :g 사용 시 의미없는 소숫점(0) 제거

print()
print(output_a)
print(output_b)