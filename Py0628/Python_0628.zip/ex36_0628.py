list_a = [273, 32, 103, "문자열", True, False]
print(list_a[3])

print(list_a[3][2])

print()
list_b = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(list_b[2])
print(list_b[2][3])
