string_a = input("숫자 입력> ")
int_a = int(string_a)

string_b = input("숫자 입력> ")
int_b = int(string_b)

