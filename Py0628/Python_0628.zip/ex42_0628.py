# 리스트를 선언합니다.
array = [273, 32, 103, 57, 52]

# 리스트에 반복문을 적용합니다.
for element in array:
    # 출력합니다.
    print(element)

