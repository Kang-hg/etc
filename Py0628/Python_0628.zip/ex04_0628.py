srt_input = input("원의 반지름 입력> ")
num_input = float(srt_input)

print()
print("반지름: ", num_input)
print("둘레: ", 2 * 3.14 * num_input)
print("넓이: ", 3.14 * num_input ** 2)