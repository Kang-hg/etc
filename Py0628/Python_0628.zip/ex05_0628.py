# format() 함수로 숫자를 문자열로 변환하기
string_a = "{}".format(10)

#출력하기
print(string_a)
print(type(string_a))

string_b = "{}, {}, {}".format(10, 20, 30)

print(string_b)
print(type(string_b))
