dict_a = {
    "name": "어벤져스 엔드게임",
    "type": "히어로 무비"
}
print()
print(dict_a)
print()
print(dict_a["name"])
print(dict_a["type"])
print()
