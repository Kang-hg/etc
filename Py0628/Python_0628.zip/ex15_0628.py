output_a = "안녕안녕하세요".find("안녕")
print(output_a)

output_b = "안녕안녕안녕안안녕녕하세요".rfind("안녕")
print(output_b)
