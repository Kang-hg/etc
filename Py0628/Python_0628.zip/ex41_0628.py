list_a = [273, 32, 103, 57, 52]
print(273 not in list_a)
print()

print(99 not in list_a)
print()

print(100 not in list_a)
print()

print(52 not in list_a)
print()

print(273 in list_a)
print()