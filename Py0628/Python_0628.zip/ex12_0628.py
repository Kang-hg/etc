a = "Hello Python Programming...!"
a.upper()

#print(a.upper())
print(a.lower())