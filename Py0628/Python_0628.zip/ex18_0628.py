a = input("> 1번째 숫자: ")
b = input("> 2번째 숫자: ")

print()

print("{} + {} = {}".format(a, b, int(a)+int(b)))