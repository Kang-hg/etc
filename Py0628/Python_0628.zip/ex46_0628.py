list_of_list = [[1, 2, 3], [4, 5, 6, 7], [8, 9]]

print()

for element in list_of_list:
    for item in element:
        print(item)

print()
